import 'package:get/get.dart';

class SelectedController extends GetxController {}
